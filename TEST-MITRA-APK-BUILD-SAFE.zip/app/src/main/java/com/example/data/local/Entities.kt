package com.example.data.local

data class LocalProfileEntity(
    val id: String,
    val name: String,
    val mobileNumber: String,
    val role: String,
    val examTypeId: String? = null,
    val isMainAdmin: Boolean = false,
    val sessionToken: String = "",
    val deviceId: String = ""
)

data class LocalActiveTestEntity(
    val attemptId: String,
    val testId: String,
    val testName: String,
    val durationMinutes: Int,
    val startTimeMillis: Long,
    val targetEndTimeMillis: Long,
    val studentId: String,
    val totalQuestions: Int,
    val isSubmitted: Boolean = false
)

data class LocalTestAnswerEntity(
    val id: String,
    val attemptId: String,
    val questionId: String,
    val selectedAnswer: String?,
    val updatedAtMillis: Long = System.currentTimeMillis()
)
